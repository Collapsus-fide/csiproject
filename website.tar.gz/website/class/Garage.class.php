<?php

class Garage
{

}