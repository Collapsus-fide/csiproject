<?php

class PropositionAchat
{

}