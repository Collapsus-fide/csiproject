<?php
include "templates/imports.php";
$page->appendContent(<<<HTML
<div class="container">
        <h1 style="text-align:center;">Simple Html Button</h1>
        <a href="https://www.google.com/">
            <button class="btn btn-primary btn-lg">Click</button>
        </a>
    </div>
HTML
);
echo "test";